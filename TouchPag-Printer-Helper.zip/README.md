# TouchPag-Printer-Helper
Servidor local de apoio ao SelfPos Android
